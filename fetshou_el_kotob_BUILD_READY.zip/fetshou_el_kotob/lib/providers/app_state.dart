import 'package:flutter/foundation.dart';
import 'package:uuid/uuid.dart';
import '../data/bible_repository.dart';
import '../data/achievements_catalog.dart';
import '../models/bible_models.dart';
import '../services/progress_repository.dart';
import '../services/points_service.dart';
import '../services/reading_plan_service.dart';
import '../services/notification_service.dart';

class AppState extends ChangeNotifier {
  final bible = BibleRepository.instance;
  final progress = ProgressRepository.instance;
  late final PointsService points;
  late final ReadingPlanService planService;
  final _uuid = const Uuid();

  bool _ready = false;
  bool get isReady => _ready;

  Future<void> init() async {
    await bible.load();
    await progress.init();
    points = PointsService(progress, bible);
    planService = ReadingPlanService(bible, progress);
    await NotificationService.instance.init();
    await _refreshVerseNotificationIfNeeded();
    _ready = true;
    notifyListeners();
  }

  /// flutter_local_notifications cannot vary a repeating notification's
  /// content by itself — a daily "verse of the day" scheduled once will
  /// keep showing the SAME verse every day until re-scheduled. To get a
  /// genuinely different random verse each day, we re-pick and re-schedule
  /// once per calendar day, triggered whenever the app is opened. This
  /// means the verse only rotates on days the app is actually opened at
  /// least once before the notification time — it is not a true
  /// server-independent daily push, which local notifications can't do.
  Future<void> _refreshVerseNotificationIfNeeded() async {
    final s = settings;
    if (!s.verseNotificationsEnabled) return;
    final verses = progress.savedVerses;
    if (verses.isEmpty) return;
    final todayKey = _dateKey(DateTime.now());
    if (progress.lastVerseNotificationDate == todayKey) return;
    await NotificationService.instance.scheduleVerseNotification(
      verses: verses,
      preferredHour: s.verseHour,
      preferredMinute: s.verseMinute,
    );
    await progress.setLastVerseNotificationDate(todayKey);
  }

  String _dateKey(DateTime d) => '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

  // ---------- Progress read-through ----------

  int get totalChapters => bible.totalChapters;
  int get completedChapters => progress.completedCount;
  double get percentComplete =>
      totalChapters == 0 ? 0 : (completedChapters / totalChapters) * 100;

  int get completedBooksCount => bible.books
      .where((b) => progress.completedChaptersForBook(b.id) == b.chapterCount)
      .length;

  int get currentStreak => progress.currentStreak;
  int get longestStreak => progress.longestStreak;
  int get totalPoints => progress.totalPoints;

  bool isChapterCompleted(String bookId, int chapterNumber) =>
      progress.isChapterCompleted('$bookId-$chapterNumber');

  int completedChaptersForBook(String bookId) => progress.completedChaptersForBook(bookId);

  /// Highest chapter number completed in a book, or null if none read yet.
  int? lastCompletedChapterForBook(String bookId) {
    final book = bible.bookById(bookId);
    int? last;
    for (var c = 1; c <= book.chapterCount; c++) {
      if (isChapterCompleted(bookId, c)) last = c;
    }
    return last;
  }

  /// Marks a chapter complete, awards points, updates streak/achievements,
  /// and notifies listeners. Returns the points earned, or null if the
  /// chapter was already completed (no duplicate points).
  Future<int?> completeChapter(String bookId, int chapterNumber) async {
    final wasNew = await progress.markChapterComplete(bookId, chapterNumber);
    if (!wasNew) return null;
    final earned = await points.awardForChapterCompletion(
      bookId: bookId,
      chapterNumber: chapterNumber,
    );
    notifyListeners();
    return earned;
  }

  Future<void> undoChapter(String bookId, int chapterNumber) async {
    await progress.undoChapterComplete(bookId, chapterNumber);
    notifyListeners();
  }

  /// Marks every chapter of a book as already-read (onboarding "which books
  /// have you already finished" step). No points awarded for backfilled history.
  Future<void> backfillBook(String bookId) async {
    final book = bible.bookById(bookId);
    for (var c = 1; c <= book.chapterCount; c++) {
      await progress.backfillChapterComplete(bookId, c);
    }
    notifyListeners();
  }

  Future<void> setStartBook(String? bookId) async {
    final s = settings;
    s.startBookId = bookId;
    await progress.saveSettings(s);
    notifyListeners();
  }

  AchievementStats get achievementStats => AchievementStats(
        chaptersCompleted: completedChapters,
        booksCompleted: completedBooksCount,
        currentStreak: currentStreak,
        longestStreak: longestStreak,
        percentComplete: percentComplete,
      );

  List<Achievement> get unlockedAchievements =>
      achievementsCatalog.where((a) => a.isUnlocked(achievementStats)).toList();

  List<Achievement> get lockedAchievements =>
      achievementsCatalog.where((a) => !a.isUnlocked(achievementStats)).toList();

  // ---------- Saved verses ----------

  List<SavedVerse> get savedVerses => progress.savedVerses;

  Future<void> addVerse({required String reference, required String text, String? note}) async {
    final verse = SavedVerse(
      id: _uuid.v4(),
      reference: reference,
      text: text,
      note: note,
      createdAt: DateTime.now(),
    );
    await progress.saveVerse(verse);
    await points.awardForSavedVerse();
    notifyListeners();
  }

  Future<void> toggleFavoriteVerse(SavedVerse verse) async {
    await progress.updateVerse(verse.copyWith(isFavorite: !verse.isFavorite));
    notifyListeners();
  }

  Future<void> deleteVerse(String id) async {
    await progress.deleteVerse(id);
    notifyListeners();
  }

  // ---------- Reading plan ----------

  ReadingPlan? get activePlan => progress.activePlan;

  Future<void> createPlan(int days) async {
    final plan = planService.createPlan(days: days);
    await progress.savePlan(plan);
    notifyListeners();
  }

  Future<void> recalculatePlanAfterFallingBehind() async {
    final plan = activePlan;
    if (plan == null) return;
    final updated = planService.recalculate(plan);
    await progress.savePlan(updated);
    notifyListeners();
  }

  Future<void> pausePlan() async {
    final plan = activePlan;
    if (plan == null) return;
    plan.status = PlanStatus.paused;
    await progress.savePlan(plan);
    notifyListeners();
  }

  Future<void> resumePlan() async {
    final plan = activePlan;
    if (plan == null) return;
    plan.status = PlanStatus.active;
    await progress.savePlan(plan);
    notifyListeners();
  }

  DateTime estimatedFinishDate(int chaptersPerDay) =>
      planService.estimatedFinishDate(chaptersPerDay: chaptersPerDay);

  /// Returns the next [count] uncompleted chapters, starting from the
  /// user's preferred start book (if set) and wrapping through canonical
  /// order. Used for "today's reading" and the قراءتي checklist.
  List<MapEntry<String, int>> nextUncompletedChapters(int count) {
    final allBooks = bible.books;
    var orderedBooks = allBooks;
    final startId = settings.startBookId;
    if (startId != null) {
      final idx = allBooks.indexWhere((b) => b.id == startId);
      if (idx > 0) {
        orderedBooks = [...allBooks.sublist(idx), ...allBooks.sublist(0, idx)];
      }
    }
    final result = <MapEntry<String, int>>[];
    for (final book in orderedBooks) {
      for (var c = 1; c <= book.chapterCount; c++) {
        if (!isChapterCompleted(book.id, c)) {
          result.add(MapEntry(book.id, c));
          if (result.length >= count) return result;
        }
      }
    }
    return result;
  }

  // ---------- Settings ----------

  AppSettings get settings => progress.settings;

  Future<void> saveSettings(AppSettings s) async {
    await progress.saveSettings(s);
    notifyListeners();
  }
}
