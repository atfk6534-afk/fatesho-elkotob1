import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:percent_indicator/percent_indicator.dart';
import '../../providers/app_state.dart';
import '../../theme/app_theme.dart';
import '../books/books_screen.dart';
import '../plan/plan_screen.dart';
import '../verses/verses_screen.dart';
import '../my_reading/my_reading_screen.dart';
import '../stats/stats_screen.dart';
import '../achievements/achievements_screen.dart';
import '../settings/settings_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _tab = 0;

  final _tabs = const [
    _DashboardTab(),
    MyReadingScreen(embedded: true),
    BooksScreen(embedded: true),
    PlanScreen(embedded: true),
    VersesScreen(embedded: true),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(child: _tabs[_tab]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: (i) => setState(() => _tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'الرئيسية'),
          NavigationDestination(icon: Icon(Icons.checklist_outlined), selectedIcon: Icon(Icons.checklist), label: 'قراءتي'),
          NavigationDestination(icon: Icon(Icons.menu_book_outlined), selectedIcon: Icon(Icons.menu_book), label: 'الأسفار'),
          NavigationDestination(icon: Icon(Icons.calendar_today_outlined), selectedIcon: Icon(Icons.calendar_today), label: 'الخطة'),
          NavigationDestination(icon: Icon(Icons.bookmark_outline), selectedIcon: Icon(Icons.bookmark), label: 'آياتي'),
        ],
      ),
    );
  }

}

class _DashboardTab extends StatelessWidget {
  const _DashboardTab();

  String _greeting() {
    final h = DateTime.now().hour;
    if (h < 12) return 'صباح الخير';
    if (h < 17) return 'نهارك سعيد';
    return 'مساء الخير';
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final name = app.settings.userName;
    final percent = app.percentComplete;
    final remaining = app.totalChapters - app.completedChapters;
    final plan = app.activePlan;

    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              name.isEmpty ? _greeting() : '${_greeting()} يا $name',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold),
            ),
            IconButton(
              icon: const Icon(Icons.settings_outlined),
              onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const SettingsScreen())),
            ),
          ],
        ),
        const SizedBox(height: 4),
        Text(
          app.completedChapters == 0
              ? 'جاهز نبدأ؟'
              : (plan != null && DateTime.now().isAfter(plan.targetDate.subtract(const Duration(days: 0))) && remaining > 0
                  ? 'كمّل رحلتك'
                  : 'كمّل رحلتك'),
          style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: Colors.grey[600]),
        ),
        const SizedBox(height: 24),
        _ProgressCard(percent: percent, app: app, remaining: remaining),
        const SizedBox(height: 20),
        _TodayReadingCard(),
        const SizedBox(height: 20),
        Row(
          children: [
            Expanded(
              child: _MiniStat(
                icon: Icons.local_fire_department,
                label: 'أيام متتالية',
                value: '${app.currentStreak}',
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: _MiniStat(
                icon: Icons.star_outline,
                label: 'النقاط',
                value: '${app.totalPoints}',
              ),
            ),
          ],
        ),
        const SizedBox(height: 20),
        Row(
          children: [
            Expanded(
              child: OutlinedButton.icon(
                onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const StatsScreen())),
                icon: const Icon(Icons.bar_chart),
                label: const Text('الإحصائيات'),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: OutlinedButton.icon(
                onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const AchievementsScreen())),
                icon: const Icon(Icons.emoji_events_outlined),
                label: const Text('الإنجازات'),
              ),
            ),
          ],
        ),
      ],
    );
  }
}

class _ProgressCard extends StatelessWidget {
  final double percent;
  final AppState app;
  final int remaining;
  const _ProgressCard({required this.percent, required this.app, required this.remaining});

  @override
  Widget build(BuildContext context) {
    final plan = app.activePlan;
    int? daysLeft;
    if (plan != null) {
      daysLeft = plan.targetDate.difference(DateTime.now()).inDays;
    }
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            Text('رحلتك في الكتاب المقدس', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w600)),
            const SizedBox(height: 16),
            CircularPercentIndicator(
              radius: 70,
              lineWidth: 14,
              percent: (percent / 100).clamp(0, 1),
              animation: true,
              circularStrokeCap: CircularStrokeCap.round,
              progressColor: AppColors.primary,
              backgroundColor: AppColors.primary.withValues(alpha: 0.1),
              center: Text('${percent.toStringAsFixed(1)}%',
                  style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            ),
            const SizedBox(height: 16),
            Wrap(
              spacing: 20,
              runSpacing: 8,
              alignment: WrapAlignment.center,
              children: [
                Text('قرأت ${app.completedChapters} من ${app.totalChapters} إصحاح'),
                Text('قرأت ${app.completedBooksCount} من ${app.bible.books.length} سفر'),
                Text('باقي $remaining إصحاح'),
                if (daysLeft != null && daysLeft > 0) Text('باقي $daysLeft يوم'),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _TodayReadingCard extends StatelessWidget {
  const _TodayReadingCard();

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final plan = app.activePlan;
    final perDay = plan?.chaptersPerDay ?? 3;

    final todays = app.nextUncompletedChapters(perDay);

    if (todays.isEmpty) {
      return Card(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              const Icon(Icons.emoji_events, color: AppColors.accent, size: 40),
              const SizedBox(height: 8),
              Text('أتممت قراءة الكتاب المقدس كاملًا! 🎉', style: Theme.of(context).textTheme.titleMedium),
            ],
          ),
        ),
      );
    }

    final firstBook = app.bible.bookById(todays.first.key);

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('قراءة اليوم', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w600)),
            const SizedBox(height: 12),
            Text(
              '${firstBook.arabicName} — إصحاح ${todays.first.value}'
              '${todays.length > 1 ? ' (+${todays.length - 1} إصحاح إضافي)' : ''}',
              style: Theme.of(context).textTheme.bodyLarge,
            ),
            const SizedBox(height: 4),
            Text('وقت قراءة تقديري: ~${todays.length * 4} دقائق', style: Theme.of(context).textTheme.bodySmall),
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () async {
                  final entry = todays.first;
                  final earned = await app.completeChapter(entry.key, entry.value);
                  if (earned != null && context.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('خلصت الإصحاح ✓  (+$earned نقطة)')),
                    );
                  }
                },
                child: const Text('خلصت الإصحاح ✓'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _MiniStat extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  const _MiniStat({required this.icon, required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Icon(icon, color: AppColors.accent),
            const SizedBox(height: 6),
            Text(value, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            Text(label, style: Theme.of(context).textTheme.bodySmall),
          ],
        ),
      ),
    );
  }
}
