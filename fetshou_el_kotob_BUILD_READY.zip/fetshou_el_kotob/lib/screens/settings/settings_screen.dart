import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/app_state.dart';
import '../../services/notification_service.dart';
import '../../models/bible_models.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final settings = app.settings;

    return Scaffold(
      appBar: AppBar(title: const Text('الإعدادات')),
      body: ListView(
        children: [
          SwitchListTile(
            title: const Text('تذكير القراءة اليومي'),
            value: settings.notificationsEnabled,
            onChanged: (v) async {
              if (v) {
                final granted = await NotificationService.instance.requestPermission();
                if (!granted) return;
                await NotificationService.instance.scheduleDailyReminder(
                  preferredHour: settings.preferredHour,
                  preferredMinute: settings.preferredMinute,
                );
              } else {
                await NotificationService.instance.cancelDailyReminder();
              }
              settings.notificationsEnabled = v;
              app.saveSettings(settings);
            },
          ),
          ListTile(
            title: const Text('معاد تذكير القراءة'),
            subtitle: Text(_formatTime(settings.preferredHour, settings.preferredMinute)),
            trailing: const Icon(Icons.chevron_left),
            onTap: () => _pickTime(
              context,
              initialHour: settings.preferredHour,
              initialMinute: settings.preferredMinute,
              onPicked: (h, m) async {
                settings.preferredHour = h;
                settings.preferredMinute = m;
                await app.saveSettings(settings);
                if (settings.notificationsEnabled) {
                  await NotificationService.instance.scheduleDailyReminder(preferredHour: h, preferredMinute: m);
                }
              },
            ),
          ),
          SwitchListTile(
            title: const Text('إشعار آية اليوم'),
            value: settings.verseNotificationsEnabled,
            onChanged: (v) async {
              if (!v) await NotificationService.instance.cancelVerseNotification();
              settings.verseNotificationsEnabled = v;
              app.saveSettings(settings);
            },
          ),
          ListTile(
            title: const Text('معاد آية اليوم'),
            subtitle: Text(_formatTime(settings.verseHour, settings.verseMinute)),
            trailing: const Icon(Icons.chevron_left),
            onTap: () => _pickTime(
              context,
              initialHour: settings.verseHour,
              initialMinute: settings.verseMinute,
              onPicked: (h, m) async {
                settings.verseHour = h;
                settings.verseMinute = m;
                await app.saveSettings(settings);
                if (settings.verseNotificationsEnabled) {
                  await NotificationService.instance.scheduleVerseNotification(
                    verses: app.savedVerses,
                    preferredHour: h,
                    preferredMinute: m,
                  );
                }
              },
            ),
          ),
          ListTile(
            title: const Text('ابدأ القراءة من سفر'),
            subtitle: Text(settings.startBookId == null ? 'بالترتيب من البداية' : app.bible.bookById(settings.startBookId!).arabicName),
            trailing: const Icon(Icons.chevron_left),
            onTap: () => _pickStartBook(context, app),
          ),
          ListTile(
            title: const Text('وضع العرض'),
            subtitle: Text(_themeLabel(settings.themeMode)),
            trailing: const Icon(Icons.chevron_left),
            onTap: () => _showThemeDialog(context, app, settings),
          ),
          const Divider(),
          ListTile(
            title: const Text('إعادة تعيين التقدم'),
            textColor: Colors.red,
            leading: const Icon(Icons.restart_alt, color: Colors.red),
            onTap: () => _confirmReset(context),
          ),
          const ListTile(
            title: Text('عن التطبيق'),
            subtitle: Text('فتشوا الكتب — رفيقك لمتابعة قراءة الكتاب المقدس حسب التقليد القبطي الأرثوذكسي'),
          ),
          const ListTile(
            title: Text('سياسة الخصوصية'),
            subtitle: Text('التقدم يُحفظ محليًا على جهازك فقط. لا تتم مشاركة بياناتك دون إذنك.'),
          ),
        ],
      ),
    );
  }

  String _themeLabel(String mode) => switch (mode) {
        'light' => 'فاتح',
        'dark' => 'داكن',
        _ => 'حسب النظام',
      };

  void _showThemeDialog(BuildContext context, AppState app, AppSettings settings) {
    showDialog(
      context: context,
      builder: (_) => SimpleDialog(
        title: const Text('وضع العرض'),
        children: [
          SimpleDialogOption(onPressed: () { settings.themeMode = 'light'; app.saveSettings(settings); Navigator.pop(context); }, child: const Text('فاتح')),
          SimpleDialogOption(onPressed: () { settings.themeMode = 'dark'; app.saveSettings(settings); Navigator.pop(context); }, child: const Text('داكن')),
          SimpleDialogOption(onPressed: () { settings.themeMode = 'system'; app.saveSettings(settings); Navigator.pop(context); }, child: const Text('حسب النظام')),
        ],
      ),
    );
  }

  String _formatTime(int hour, int minute) {
    final period = hour >= 12 ? 'م' : 'ص';
    final h12 = hour % 12 == 0 ? 12 : hour % 12;
    return '$h12:${minute.toString().padLeft(2, '0')} $period';
  }

  Future<void> _pickTime(
    BuildContext context, {
    required int initialHour,
    required int initialMinute,
    required void Function(int hour, int minute) onPicked,
  }) async {
    final picked = await showTimePicker(
      context: context,
      initialTime: TimeOfDay(hour: initialHour, minute: initialMinute),
    );
    if (picked != null) {
      onPicked(picked.hour, picked.minute);
    }
  }

  void _pickStartBook(BuildContext context, AppState app) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (_) => DraggableScrollableSheet(
        initialChildSize: 0.7,
        expand: false,
        builder: (context, controller) => ListView(
          controller: controller,
          padding: const EdgeInsets.all(16),
          children: [
            ListTile(
              title: const Text('بالترتيب من البداية'),
              onTap: () {
                app.setStartBook(null);
                Navigator.pop(context);
              },
            ),
            const Divider(),
            ...app.bible.books.map((b) => ListTile(
                  title: Text(b.arabicName),
                  onTap: () {
                    app.setStartBook(b.id);
                    Navigator.pop(context);
                  },
                )),
          ],
        ),
      ),
    );
  }

  void _confirmReset(BuildContext context) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('تأكيد إعادة التعيين'),
        content: const Text('سيتم حذف كل تقدمك في القراءة. هذا الإجراء لا يمكن التراجع عنه.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('إلغاء')),
          TextButton(
            onPressed: () {
              // Actual data wipe is left to a dedicated repository method in
              // a future pass; confirmation UX is in place per spec.
              Navigator.pop(context);
            },
            child: const Text('حذف', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }
}
