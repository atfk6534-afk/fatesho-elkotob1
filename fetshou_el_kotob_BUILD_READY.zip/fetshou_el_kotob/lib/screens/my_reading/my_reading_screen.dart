import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/app_state.dart';
import '../../theme/app_theme.dart';
import '../verses/add_verse_sheet.dart';

/// "قراءتي" — a task-list style view of upcoming reading days, grouped by
/// day according to the active plan's daily pace (or a sensible default).
/// Tapping a chapter toggles it complete/undo, same as the book grid, but
/// framed as a checklist so progress feels like ticking off tasks.
class MyReadingScreen extends StatelessWidget {
  final bool embedded;
  const MyReadingScreen({super.key, this.embedded = false});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final perDay = app.activePlan?.chaptersPerDay ?? 3;
    const daysToShow = 14;
    final upcoming = app.nextUncompletedChapters(perDay * daysToShow);

    final body = upcoming.isEmpty
        ? Center(
            child: Padding(
              padding: const EdgeInsets.all(32),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.emoji_events, color: AppColors.accent, size: 48),
                  const SizedBox(height: 12),
                  Text('أتممت كل قراءاتك المجدولة! 🎉', style: Theme.of(context).textTheme.titleMedium),
                ],
              ),
            ),
          )
        : ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: (upcoming.length / perDay).ceil(),
            itemBuilder: (context, dayIndex) {
              final start = dayIndex * perDay;
              final end = (start + perDay).clamp(0, upcoming.length);
              final dayChapters = upcoming.sublist(start, end);
              return _DayCard(dayIndex: dayIndex, chapters: dayChapters);
            },
          );

    if (embedded) return body;
    return Scaffold(appBar: AppBar(title: const Text('قراءتي')), body: body);
  }
}

class _DayCard extends StatelessWidget {
  final int dayIndex;
  final List<MapEntry<String, int>> chapters;
  const _DayCard({required this.dayIndex, required this.chapters});

  String _label() {
    switch (dayIndex) {
      case 0:
        return 'اليوم';
      case 1:
        return 'غدًا';
      default:
        return 'بعد $dayIndex أيام';
    }
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(_label(),
                style: Theme.of(context)
                    .textTheme
                    .titleSmall
                    ?.copyWith(color: dayIndex == 0 ? AppColors.primary : Colors.grey, fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            ...chapters.map((entry) {
              final book = app.bible.bookById(entry.key);
              final done = app.isChapterCompleted(entry.key, entry.value);
              return CheckboxListTile(
                contentPadding: EdgeInsets.zero,
                controlAffinity: ListTileControlAffinity.leading,
                value: done,
                title: Text('${book.arabicName} — إصحاح ${entry.value}',
                    style: TextStyle(decoration: done ? TextDecoration.lineThrough : null)),
                onChanged: (v) async {
                  if (v == true) {
                    final earned = await app.completeChapter(entry.key, entry.value);
                    if (earned != null && context.mounted) {
                      ScaffoldMessenger.of(context)
                          .showSnackBar(SnackBar(content: Text('تمام ✓ (+$earned نقطة)')));
                      if (context.mounted) offerSaveVerse(context);
                    }
                  } else {
                    await app.undoChapter(entry.key, entry.value);
                  }
                },
              );
            }),
          ],
        ),
      ),
    );
  }
}
