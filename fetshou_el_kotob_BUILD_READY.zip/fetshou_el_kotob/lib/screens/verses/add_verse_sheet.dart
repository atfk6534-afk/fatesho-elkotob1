import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/app_state.dart';

/// Shows the "save a verse" bottom sheet. Call this after any chapter
/// completion, from any screen, so the prompt is consistent everywhere.
void offerSaveVerse(BuildContext context, {String promptTitle = 'في آية لمستك النهارده؟'}) {
  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    builder: (_) => AddVerseSheet(promptTitle: promptTitle),
  );
}

class AddVerseSheet extends StatefulWidget {
  final String promptTitle;
  const AddVerseSheet({super.key, this.promptTitle = 'أضف آية'});

  @override
  State<AddVerseSheet> createState() => _AddVerseSheetState();
}

class _AddVerseSheetState extends State<AddVerseSheet> {
  final _refController = TextEditingController();
  final _textController = TextEditingController();
  final _noteController = TextEditingController();
  int _savedCount = 0;

  @override
  void dispose() {
    _refController.dispose();
    _textController.dispose();
    _noteController.dispose();
    super.dispose();
  }

  bool get _canSave => _textController.text.trim().isNotEmpty && _refController.text.trim().isNotEmpty;

  Future<void> _save({required bool closeAfter}) async {
    if (!_canSave) return;
    await context.read<AppState>().addVerse(
          reference: _refController.text.trim(),
          text: _textController.text.trim(),
          note: _noteController.text.trim().isEmpty ? null : _noteController.text.trim(),
        );
    setState(() => _savedCount += 1);
    _refController.clear();
    _textController.clear();
    _noteController.clear();
    if (closeAfter && mounted) Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).viewInsets.bottom + 20,
        left: 20,
        right: 20,
        top: 20,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Center(
            child: Container(
              width: 40,
              height: 4,
              margin: const EdgeInsets.only(bottom: 16),
              decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(4)),
            ),
          ),
          Text(widget.promptTitle, style: Theme.of(context).textTheme.titleMedium, textAlign: TextAlign.center),
          if (_savedCount > 0) ...[
            const SizedBox(height: 6),
            Text('اتحفظ $_savedCount آية ✓', textAlign: TextAlign.center, style: const TextStyle(color: Colors.green)),
          ],
          const SizedBox(height: 16),
          TextField(
            controller: _refController,
            decoration: const InputDecoration(labelText: 'المرجع (مثال: يوحنا 3:16)', border: OutlineInputBorder()),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _textController,
            maxLines: 3,
            decoration: const InputDecoration(labelText: 'نص الآية', border: OutlineInputBorder()),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _noteController,
            decoration: const InputDecoration(labelText: 'ملاحظة شخصية (اختياري)', border: OutlineInputBorder()),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: TextButton(
                  onPressed: () => Navigator.of(context).pop(),
                  child: Text(_savedCount > 0 ? 'تم' : 'لاحقًا'),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: OutlinedButton(
                  onPressed: _canSave ? () => _save(closeAfter: false) : null,
                  child: const Text('احفظ وأضف كمان'),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: ElevatedButton(
                  onPressed: _canSave ? () => _save(closeAfter: true) : null,
                  child: const Text('احفظ'),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
