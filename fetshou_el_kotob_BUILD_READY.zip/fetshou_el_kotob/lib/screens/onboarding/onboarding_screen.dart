import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/app_state.dart';
import '../../services/notification_service.dart';
import '../../theme/app_theme.dart';
import '../home/home_screen.dart';

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final _controller = PageController();
  int _page = 0;
  int? _selectedDays;
  int _preferredHour = 20;
  int _preferredMinute = 0;
  int _verseHour = 9;
  int _verseMinute = 0;
  final Set<String> _completedBookIds = {};
  String? _startBookId;

  static const int totalPages = 8;

  void _next() {
    if (_page < totalPages - 1) {
      _controller.nextPage(duration: const Duration(milliseconds: 300), curve: Curves.easeOut);
    } else {
      _finish();
    }
  }

  Future<void> _finish() async {
    final app = context.read<AppState>();
    for (final bookId in _completedBookIds) {
      await app.backfillBook(bookId);
    }
    if (_selectedDays != null) {
      await app.createPlan(_selectedDays!);
    }
    await app.setStartBook(_startBookId);
    final settings = app.settings;
    settings.preferredHour = _preferredHour;
    settings.preferredMinute = _preferredMinute;
    settings.verseHour = _verseHour;
    settings.verseMinute = _verseMinute;
    settings.onboardingComplete = true;
    await app.saveSettings(settings);
    if (!mounted) return;
    Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const HomeScreen()));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: PageView(
                controller: _controller,
                onPageChanged: (i) => setState(() => _page = i),
                children: [
                  _WelcomePage(onNext: _next),
                  _IntroStatsPage(onNext: _next),
                  _MotivationPage(onNext: _next),
                  _WhereAreYouPage(onNext: _next),
                  _CompletedBooksPage(
                    selected: _completedBookIds,
                    onToggle: (id) => setState(() {
                      if (_completedBookIds.contains(id)) {
                        _completedBookIds.remove(id);
                      } else {
                        _completedBookIds.add(id);
                      }
                    }),
                    onNext: _next,
                  ),
                  _StartBookPage(
                    excluded: _completedBookIds,
                    selected: _startBookId,
                    onSelect: (id) => setState(() => _startBookId = id),
                    onNext: _next,
                  ),
                  _GoalPage(
                    selectedDays: _selectedDays,
                    onSelect: (d) => setState(() => _selectedDays = d),
                    onNext: _next,
                  ),
                  _ReadingTimePage(
                    onReadingTime: (h, m) => setState(() {
                      _preferredHour = h;
                      _preferredMinute = m;
                    }),
                    onVerseTime: (h, m) => setState(() {
                      _verseHour = h;
                      _verseMinute = m;
                    }),
                    onFinish: _finish,
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: List.generate(totalPages, (i) {
                  final active = i == _page;
                  return AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    margin: const EdgeInsets.symmetric(horizontal: 4),
                    width: active ? 22 : 8,
                    height: 8,
                    decoration: BoxDecoration(
                      color: active ? AppColors.primary : AppColors.primary.withValues(alpha: 0.2),
                      borderRadius: BorderRadius.circular(4),
                    ),
                  );
                }),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _PageScaffold extends StatelessWidget {
  final Widget child;
  final String? buttonLabel;
  final VoidCallback? onNext;
  final bool scrollable;

  const _PageScaffold({required this.child, this.buttonLabel, this.onNext, this.scrollable = false});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 28),
      child: Column(
        children: [
          Expanded(
            child: scrollable
                ? SingleChildScrollView(child: child)
                : Center(child: child),
          ),
          if (onNext != null)
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: onNext,
                child: Text(buttonLabel ?? 'التالي'),
              ),
            ),
          const SizedBox(height: 12),
        ],
      ),
    );
  }
}

class _WelcomePage extends StatelessWidget {
  final VoidCallback onNext;
  const _WelcomePage({required this.onNext});

  @override
  Widget build(BuildContext context) {
    return _PageScaffold(
      onNext: onNext,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const _CrossMotif(size: 100),
          const SizedBox(height: 24),
          Text('فتشوا الكتب',
              style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.bold)),
          const SizedBox(height: 16),
          Text(
            '"لأنكم تظنون أن لكم فيها حياة أبدية، وهي التي تشهد لي."',
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.titleMedium?.copyWith(fontStyle: FontStyle.italic),
          ),
          const SizedBox(height: 8),
          Text('يوحنا 5:39', style: Theme.of(context).textTheme.bodySmall),
        ],
      ),
    );
  }
}

/// Original, simple decorative cross-and-halo motif (drawn with basic
/// shapes, not a reproduction of any existing icon or artwork) used to add
/// a warmer, more liturgical feel without any copyright concerns.
class _CrossMotif extends StatelessWidget {
  final double size;
  const _CrossMotif({this.size = 80});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size,
      height: size,
      child: CustomPaint(painter: _CrossPainter()),
    );
  }
}

class _CrossPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final haloPaint = Paint()
      ..color = AppColors.accent.withValues(alpha: 0.18)
      ..style = PaintingStyle.fill;
    canvas.drawCircle(center, size.width / 2, haloPaint);

    final ringPaint = Paint()
      ..color = AppColors.accent
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2;
    canvas.drawCircle(center, size.width / 2 - 4, ringPaint);

    final crossPaint = Paint()
      ..color = AppColors.primary
      ..style = PaintingStyle.fill;
    final barW = size.width * 0.14;
    // Vertical bar
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromCenter(center: center, width: barW, height: size.height * 0.62),
        const Radius.circular(4),
      ),
      crossPaint,
    );
    // Horizontal bar (slightly above center, Orthodox-style proportions)
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromCenter(
          center: Offset(center.dx, center.dy - size.height * 0.06),
          width: size.width * 0.5,
          height: barW,
        ),
        const Radius.circular(4),
      ),
      crossPaint,
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _IntroStatsPage extends StatelessWidget {
  final VoidCallback onNext;
  const _IntroStatsPage({required this.onNext});

  @override
  Widget build(BuildContext context) {
    return _PageScaffold(
      onNext: onNext,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            'فتشوا الكتب هو رفيقك لمتابعة قراءتك في الكتاب المقدس، خطوة بخطوة، إصحاحًا بعد إصحاح.',
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.titleMedium,
          ),
          const SizedBox(height: 28),
          Wrap(
            spacing: 16,
            runSpacing: 16,
            alignment: WrapAlignment.center,
            children: const [
              _StatChip(number: '73', label: 'سفرًا'),
              _StatChip(number: '1335', label: 'إصحاحًا فعليًا'),
              _StatChip(number: '46', label: 'سفرًا في العهد القديم'),
              _StatChip(number: '27', label: 'سفرًا في العهد الجديد'),
            ],
          ),
          const SizedBox(height: 24),
          Text(
            'يتبع التطبيق ترتيب الكتاب المقدس كما تسلّمته الكنيسة القبطية الأرثوذكسية، ويشمل الأسفار القانونية الثانية في مواضعها التقليدية.',
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.bodyMedium,
          ),
        ],
      ),
    );
  }
}

class _StatChip extends StatelessWidget {
  final String number;
  final String label;
  const _StatChip({required this.number, required this.label});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 130,
      padding: const EdgeInsets.symmetric(vertical: 18),
      decoration: BoxDecoration(
        color: AppColors.primary.withValues(alpha: 0.06),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        children: [
          Text(number, style: const TextStyle(fontSize: 28, fontWeight: FontWeight.bold, color: AppColors.primary)),
          const SizedBox(height: 4),
          Text(label, textAlign: TextAlign.center, style: const TextStyle(fontSize: 13)),
        ],
      ),
    );
  }
}

class _MotivationPage extends StatelessWidget {
  final VoidCallback onNext;
  const _MotivationPage({required this.onNext});

  @override
  Widget build(BuildContext context) {
    return _PageScaffold(
      onNext: onNext,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          _VerseCard(text: 'فتشوا الكتب، لأنكم تظنون أن لكم فيها حياة أبدية.', ref: 'يوحنا 5:39'),
          const SizedBox(height: 16),
          _VerseCard(text: 'سراج لرجلي كلامك ونور لسبيلي.', ref: 'مزمور 119:105'),
          const SizedBox(height: 16),
          _VerseCard(text: 'أما أنت فاثبت على ما تعلمت.', ref: '2 تيموثاوس 3:14'),
        ],
      ),
    );
  }
}

class _VerseCard extends StatelessWidget {
  final String text;
  final String ref;
  const _VerseCard({required this.text, required this.ref});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: AppColors.accent.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(14),
        border: Border(right: BorderSide(color: AppColors.accent, width: 3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Text(text, textAlign: TextAlign.right, style: Theme.of(context).textTheme.titleSmall),
          const SizedBox(height: 6),
          Text(ref, style: Theme.of(context).textTheme.bodySmall?.copyWith(color: AppColors.accent)),
        ],
      ),
    );
  }
}

class _WhereAreYouPage extends StatelessWidget {
  final VoidCallback onNext;
  const _WhereAreYouPage({required this.onNext});

  static const options = [
    'لم أبدأ بعد',
    'قرأت بعض الإصحاحات',
    'قرأت عدة أسفار',
    'أنا بالفعل أقرأ الكتاب بانتظام',
  ];

  @override
  Widget build(BuildContext context) {
    return _PageScaffold(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text('إنت وصلت لفين؟', style: Theme.of(context).textTheme.headlineSmall),
          const SizedBox(height: 24),
          ...options.map((o) => Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: SizedBox(
                  width: double.infinity,
                  child: OutlinedButton(
                    onPressed: onNext,
                    child: Text(o),
                  ),
                ),
              )),
        ],
      ),
    );
  }
}

class _CompletedBooksPage extends StatelessWidget {
  final Set<String> selected;
  final void Function(String bookId) onToggle;
  final VoidCallback onNext;
  const _CompletedBooksPage({required this.selected, required this.onToggle, required this.onNext});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(28, 24, 28, 8),
          child: Column(
            children: [
              Text('حدد الأسفار اللي خلصتها قبل كده', textAlign: TextAlign.center, style: Theme.of(context).textTheme.headlineSmall),
              const SizedBox(height: 6),
              Text('عشان متضطرش تعيد قراءتها تاني (اختياري)', textAlign: TextAlign.center, style: Theme.of(context).textTheme.bodySmall),
            ],
          ),
        ),
        Expanded(
          child: ListView.builder(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            itemCount: app.bible.books.length,
            itemBuilder: (context, i) {
              final b = app.bible.books[i];
              final isSelected = selected.contains(b.id);
              return CheckboxListTile(
                value: isSelected,
                onChanged: (_) => onToggle(b.id),
                title: Text(b.arabicName),
                subtitle: Text('${b.chapterCount} إصحاح'),
                dense: true,
              );
            },
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(28, 8, 28, 12),
          child: SizedBox(
            width: double.infinity,
            child: ElevatedButton(onPressed: onNext, child: Text(selected.isEmpty ? 'تخطي' : 'التالي')),
          ),
        ),
      ],
    );
  }
}

class _StartBookPage extends StatelessWidget {
  final Set<String> excluded;
  final String? selected;
  final ValueChanged<String?> onSelect;
  final VoidCallback onNext;
  const _StartBookPage({required this.excluded, required this.selected, required this.onSelect, required this.onNext});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final remainingBooks = app.bible.books.where((b) => !excluded.contains(b.id)).toList();
    return _PageScaffold(
      onNext: onNext,
      scrollable: true,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text('حب تبدأ بإيه؟', textAlign: TextAlign.center, style: Theme.of(context).textTheme.headlineSmall),
          const SizedBox(height: 20),
          RadioListTile<String?>(
            value: null,
            groupValue: selected,
            onChanged: onSelect,
            title: const Text('بالترتيب القانوني (الأفضل)'),
          ),
          ...remainingBooks.take(15).map((b) => RadioListTile<String?>(
                value: b.id,
                groupValue: selected,
                onChanged: onSelect,
                title: Text(b.arabicName),
              )),
          const SizedBox(height: 8),
          Text('يمكنك تغيير ده لاحقًا من الإعدادات', style: Theme.of(context).textTheme.bodySmall),
        ],
      ),
    );
  }
}

class _GoalPage extends StatefulWidget {
  final int? selectedDays;
  final ValueChanged<int> onSelect;
  final VoidCallback onNext;
  const _GoalPage({required this.selectedDays, required this.onSelect, required this.onNext});

  @override
  State<_GoalPage> createState() => _GoalPageState();
}

class _GoalPageState extends State<_GoalPage> {
  static const Map<String, int> options = {
    '30 يوم': 30,
    '60 يوم': 60,
    '90 يوم': 90,
    '6 شهور': 182,
    'سنة': 365,
  };

  final _customController = TextEditingController();
  bool _customMode = false;

  @override
  void dispose() {
    _customController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return _PageScaffold(
      onNext: widget.selectedDays != null ? widget.onNext : null,
      buttonLabel: 'حساب خطتي',
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text('عايز تخلص الكتاب المقدس في قد إيه؟', textAlign: TextAlign.center, style: Theme.of(context).textTheme.headlineSmall),
          const SizedBox(height: 24),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            alignment: WrapAlignment.center,
            children: [
              ...options.entries.map((e) {
                final selected = !_customMode && widget.selectedDays == e.value;
                return ChoiceChip(
                  label: Text(e.key),
                  selected: selected,
                  onSelected: (_) {
                    setState(() => _customMode = false);
                    widget.onSelect(e.value);
                  },
                );
              }),
              ChoiceChip(
                label: const Text('عدد أيام مخصص'),
                selected: _customMode,
                onSelected: (_) => setState(() => _customMode = true),
              ),
            ],
          ),
          if (_customMode) ...[
            const SizedBox(height: 16),
            SizedBox(
              width: 180,
              child: TextField(
                controller: _customController,
                keyboardType: TextInputType.number,
                textAlign: TextAlign.center,
                decoration: const InputDecoration(
                  labelText: 'عدد الأيام',
                  border: OutlineInputBorder(),
                ),
                onChanged: (v) {
                  final n = int.tryParse(v);
                  if (n != null && n > 0) widget.onSelect(n);
                },
              ),
            ),
          ],
        ],
      ),
    );
  }
}

class _ReadingTimePage extends StatefulWidget {
  final void Function(int hour, int minute) onReadingTime;
  final void Function(int hour, int minute) onVerseTime;
  final VoidCallback onFinish;
  const _ReadingTimePage({required this.onReadingTime, required this.onVerseTime, required this.onFinish});

  @override
  State<_ReadingTimePage> createState() => _ReadingTimePageState();
}

class _ReadingTimePageState extends State<_ReadingTimePage> {
  TimeOfDay _readingTime = const TimeOfDay(hour: 20, minute: 0);
  TimeOfDay _verseTime = const TimeOfDay(hour: 9, minute: 0);
  bool _askedPermission = false;

  Future<void> _pickReadingTime() async {
    final picked = await showTimePicker(context: context, initialTime: _readingTime);
    if (picked != null) {
      setState(() => _readingTime = picked);
      widget.onReadingTime(picked.hour, picked.minute);
    }
  }

  Future<void> _pickVerseTime() async {
    final picked = await showTimePicker(context: context, initialTime: _verseTime);
    if (picked != null) {
      setState(() => _verseTime = picked);
      widget.onVerseTime(picked.hour, picked.minute);
    }
  }

  Future<void> _allowNotifications() async {
    setState(() => _askedPermission = true);
    await NotificationService.instance.requestPermission();
  }

  String _fmt(TimeOfDay t) {
    final period = t.hour >= 12 ? 'م' : 'ص';
    final h12 = t.hour % 12 == 0 ? 12 : t.hour % 12;
    return '$h12:${t.minute.toString().padLeft(2, '0')} $period';
  }

  @override
  void initState() {
    super.initState();
    widget.onReadingTime(_readingTime.hour, _readingTime.minute);
    widget.onVerseTime(_verseTime.hour, _verseTime.minute);
  }

  @override
  Widget build(BuildContext context) {
    return _PageScaffold(
      onNext: () => widget.onFinish(),
      buttonLabel: 'ابدأ الرحلة',
      scrollable: true,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text('إمتى تحب تتذكر بقراءتك؟', textAlign: TextAlign.center, style: Theme.of(context).textTheme.headlineSmall),
          const SizedBox(height: 20),
          OutlinedButton.icon(
            onPressed: _pickReadingTime,
            icon: const Icon(Icons.access_time),
            label: Text('معاد تذكير القراءة: ${_fmt(_readingTime)}'),
          ),
          const SizedBox(height: 12),
          OutlinedButton.icon(
            onPressed: _pickVerseTime,
            icon: const Icon(Icons.favorite_border),
            label: Text('معاد آية اليوم: ${_fmt(_verseTime)}'),
          ),
          const SizedBox(height: 24),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppColors.primary.withValues(alpha: 0.06),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Column(
              children: [
                const Icon(Icons.notifications_active_outlined, color: AppColors.primary, size: 32),
                const SizedBox(height: 8),
                Text(
                  'نقدر نفكّرك كل يوم بوقت قراءتك، ونبعتلك آية من الآيات اللي حفظتها في معاد تاني تختاره.',
                  textAlign: TextAlign.center,
                  style: Theme.of(context).textTheme.bodyMedium,
                ),
                const SizedBox(height: 12),
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    ElevatedButton(
                      onPressed: _askedPermission ? null : _allowNotifications,
                      child: Text(_askedPermission ? 'تم ✓' : 'السماح بالإشعارات'),
                    ),
                    const SizedBox(width: 8),
                    TextButton(
                      onPressed: () => setState(() => _askedPermission = true),
                      child: const Text('لاحقًا'),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
