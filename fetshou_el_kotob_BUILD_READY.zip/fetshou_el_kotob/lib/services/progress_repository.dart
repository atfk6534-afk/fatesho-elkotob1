import 'package:hive_flutter/hive_flutter.dart';
import '../models/bible_models.dart';

/// All local, offline-first persistence lives here. Uses Hive boxes as a
/// simple embedded key-value store — stable on Android, no native plugin
/// build issues, works fully offline.
class ProgressRepository {
  ProgressRepository._();
  static final ProgressRepository instance = ProgressRepository._();

  static const _completedBox = 'completed_chapters';
  static const _versesBox = 'saved_verses';
  static const _plansBox = 'reading_plans';
  static const _settingsBox = 'app_settings';
  static const _pointsBox = 'points';
  static const _streakBox = 'streak';

  late Box _completed;
  late Box _verses;
  late Box _plans;
  late Box _settings;
  late Box _points;
  late Box _streak;

  bool _initialized = false;

  Future<void> init() async {
    if (_initialized) return;
    await Hive.initFlutter();
    _completed = await Hive.openBox(_completedBox);
    _verses = await Hive.openBox(_versesBox);
    _plans = await Hive.openBox(_plansBox);
    _settings = await Hive.openBox(_settingsBox);
    _points = await Hive.openBox(_pointsBox);
    _streak = await Hive.openBox(_streakBox);
    _initialized = true;
  }

  // ---------- Completed chapters ----------

  bool isChapterCompleted(String chapterId) => _completed.containsKey(chapterId);

  List<CompletedChapter> get allCompleted =>
      _completed.values.map((m) => CompletedChapter.fromMap(Map.from(m as Map))).toList();

  int get completedCount => _completed.length;

  /// Marks a chapter complete. Returns false if it was already completed
  /// (so callers never award points twice).
  Future<bool> markChapterComplete(String bookId, int chapterNumber) async {
    final chapterId = '$bookId-$chapterNumber';
    if (_completed.containsKey(chapterId)) return false;
    final record = CompletedChapter(
      chapterId: chapterId,
      bookId: bookId,
      chapterNumber: chapterNumber,
      completedAt: DateTime.now(),
    );
    await _completed.put(chapterId, record.toMap());
    await _touchStreak();
    return true;
  }

  /// Marks a chapter as already-read history (used during onboarding when
  /// the user selects books they'd finished before installing the app).
  /// Does not award points — points are only for new reading going forward.
  Future<void> backfillChapterComplete(String bookId, int chapterNumber) async {
    final chapterId = '$bookId-$chapterNumber';
    if (_completed.containsKey(chapterId)) return;
    final record = CompletedChapter(
      chapterId: chapterId,
      bookId: bookId,
      chapterNumber: chapterNumber,
      completedAt: DateTime.now(),
    );
    await _completed.put(chapterId, record.toMap());
  }

  /// Undo an accidental completion. Does not reverse points automatically
  /// in this simple model — see PointsService for point history if needed.
  Future<void> undoChapterComplete(String bookId, int chapterNumber) async {
    final chapterId = '$bookId-$chapterNumber';
    await _completed.delete(chapterId);
  }

  int completedChaptersForBook(String bookId) =>
      _completed.values.where((m) => (m as Map)['bookId'] == bookId).length;

  // ---------- Streak ----------

  Future<void> _touchStreak() async {
    final todayKey = _dayKey(DateTime.now());
    final lastKey = _streak.get('lastDay') as String?;
    if (lastKey == todayKey) return; // already counted today

    final yesterdayKey = _dayKey(DateTime.now().subtract(const Duration(days: 1)));
    int current = (_streak.get('current') as int?) ?? 0;
    int longest = (_streak.get('longest') as int?) ?? 0;

    if (lastKey == yesterdayKey) {
      current += 1;
    } else {
      current = 1; // streak broken or first ever read
    }
    if (current > longest) longest = current;

    await _streak.put('lastDay', todayKey);
    await _streak.put('current', current);
    await _streak.put('longest', longest);
  }

  int get currentStreak => (_streak.get('current') as int?) ?? 0;
  int get longestStreak => (_streak.get('longest') as int?) ?? 0;

  String _dayKey(DateTime d) => '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

  // ---------- Saved verses ----------

  List<SavedVerse> get savedVerses =>
      _verses.values.map((m) => SavedVerse.fromMap(Map.from(m as Map))).toList()
        ..sort((a, b) => b.createdAt.compareTo(a.createdAt));

  Future<void> saveVerse(SavedVerse verse) async => _verses.put(verse.id, verse.toMap());

  Future<void> deleteVerse(String id) async => _verses.delete(id);

  Future<void> updateVerse(SavedVerse verse) async => _verses.put(verse.id, verse.toMap());

  // ---------- Reading plan ----------

  ReadingPlan? get activePlan {
    for (final v in _plans.values) {
      final plan = ReadingPlan.fromMap(Map.from(v as Map));
      if (plan.status == PlanStatus.active || plan.status == PlanStatus.paused) return plan;
    }
    return null;
  }

  Future<void> savePlan(ReadingPlan plan) async => _plans.put(plan.id, plan.toMap());

  Future<void> deletePlan(String id) async => _plans.delete(id);

  // ---------- Settings ----------

  AppSettings get settings {
    final map = _settings.get('settings');
    if (map == null) return AppSettings();
    return AppSettings.fromMap(Map.from(map as Map));
  }

  Future<void> saveSettings(AppSettings s) async => _settings.put('settings', s.toMap());

  // ---------- Verse notification rotation ----------

  /// The date (YYYY-MM-DD) the verse-of-the-day notification content was
  /// last (re)randomized, or null if never scheduled.
  String? get lastVerseNotificationDate => _settings.get('lastVerseNotificationDate') as String?;

  Future<void> setLastVerseNotificationDate(String dayKey) async =>
      _settings.put('lastVerseNotificationDate', dayKey);

  // ---------- Points ----------

  int get totalPoints => (_points.get('total') as int?) ?? 0;

  Future<void> addPoints(int amount) async {
    final current = totalPoints;
    await _points.put('total', current + amount);
  }
}
