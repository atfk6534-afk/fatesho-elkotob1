# فتشوا الكتب (Fetshou El Kotob)

تطبيق متابعة قراءة الكتاب المقدس حسب تقليد الكنيسة القبطية الأرثوذكسية.

## حالة المشروع (MVP)

تم بناء النواة الوظيفية الكاملة التالية:

- بيانات الكتاب المقدس القانونية الكاملة (73 سفرًا) في `assets/data/bible_canon.json`
- `BibleValidator` + اختبارات تتحقق من الأرقام القانونية آليًا
- تتبع الإصحاحات دون اتصال بالإنترنت (Hive) — منع تكرار النقاط عند تكرار الإكمال
- شاشات: الترحيب (Onboarding)، الرئيسية، الأسفار، تفاصيل السفر/الإصحاحات، خطة القراءة، آياتي، الإحصائيات، الإنجازات، الإعدادات
- نظام نقاط، سلسلة أيام (streak)، إنجازات
- إشعارات محلية (تذكير قراءة + آية اليوم) مع نافذة زمنية عشوائية
- سير عمل GitHub Actions لبناء APK تلقائيًا

## ⚠️ ملاحظة مهمة عن العدد الإجمالي للإصحاحات

تم التحقق حسابيًا من أن العهد القديم يحتوي على **46 سفرًا و1075 إصحاحًا بالضبط**، بما يشمل الأسفار القانونية الثانية (طوبيا، يهوديت، الحكمة، يشوع بن سيراخ، باروخ، المكابيين الأول والثاني) وتتمات أستير ودانيال والمزمور 151 مدمجة ضمن الأسفار الأصلية.

العهد الجديد يتكوّن من نفس الـ27 سفرًا في كل التقاليد المسيحية، ومجموع إصحاحاته المعياري هو **260** وليس 270. لذلك الإجمالي الفعلي في هذا الإصدار هو **1335 إصحاحًا** وليس 1345. لم يتم اختلاق 10 إصحاحات إضافية لتحقيق الرقم المطلوب. إذا توفر مصدر قبطي موثّق يوضح عدًا مختلفًا للعهد الجديد، يمكن تحديث الثوابت في `lib/services/bible_validator.dart` وتوثيق المصدر في ملف JSON.

## غير مكتمل بعد (الخطوات التالية)

- نظام الأصدقاء ولوحة المتصدرين (Firebase/Supabase) — البنية معمارية بحيث يمكن إضافته لاحقًا دون إعادة كتابة الجزء الأساسي
- تفعيل حذف التقدم فعليًا من شاشة الإعدادات (الواجهة وتأكيد الحذف جاهزان، منطق المسح الفعلي من Hive يحتاج إكمال)
- خط عربي مخصص (Cairo/Tajawal) — البنية جاهزة لإضافته عبر `pubspec.yaml`
- نص آيات مرخّص قانونيًا لملء الإشعارات تلقائيًا دون اعتماد المستخدم على الإدخال اليدوي فقط
- اختبارات إضافية لمنطق الإشعارات والتخزين المحلي بشكل مباشر (الحالي يغطي منطق البيانات والحسابات)

## طريقة البناء عبر GitHub Actions

1. ارفع هذا المشروع كاملًا (بعد فك الضغط) إلى مستودع جديد على GitHub.
2. تأكد من وجود الملف `.github/workflows/build-apk.yml` (موجود بالفعل).
3. من تبويب Actions في المستودع، شغّل الـ workflow يدويًا (workflow_dispatch) أو ادفع (push) على فرع main.
4. بعد اكتمال البناء، حمّل ملف APK من قسم Artifacts في تشغيل الـ workflow.

## البناء محليًا (إن توفر جهاز به Flutter مثبت)

```
flutter pub get
flutter test
flutter build apk --release
```


## GitHub Actions: building from a ZIP

The included workflow can build the project normally, and it can also unpack a project ZIP when the repository root does not yet contain `pubspec.yaml`.

**Important GitHub limitation:** GitHub Actions cannot run a workflow that is still buried inside a ZIP file. If you upload `fetshou_el_kotob.zip` as one file to a new repository, GitHub stores it as a ZIP; it does not unpack it automatically.

For a ZIP-only repository, do this once:

1. Create an empty GitHub repository.
2. Create `.github/workflows/build-apk.yml` in that repository using the supplied `build-apk-from-zip.yml`.
3. Upload `fetshou_el_kotob.zip` to the repository root.
4. Push to `main` or run the workflow manually.
5. The workflow unpacks the ZIP, finds `pubspec.yaml`, installs Flutter dependencies, runs formatting/analyzer/tests, builds the release APK, and uploads the APK as an Actions artifact.

After the first successful extraction, you can instead commit the extracted Flutter project directly; the same workflow supports both layouts.


### Canon chapter-count note

The Coptic Orthodox Church website currently states 46 Old Testament books / 1075 chapters and 27 New Testament books / 270 chapters. St-Takla repeats the same published figure. However, enumerating the 27 New Testament books by their actual chapter ranges gives 260 chapters, so the concrete chapter dataset in this app contains **1335 trackable chapters** (1075 + 260). The source-reported 270/1345 figures are preserved in `BibleMeta` for transparency; the app does not create ten fictional chapter records.
