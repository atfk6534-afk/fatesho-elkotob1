package com.rocaalamir.fetshou_el_kotob

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
