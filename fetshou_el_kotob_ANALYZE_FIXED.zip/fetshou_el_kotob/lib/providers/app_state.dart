import 'package:flutter/foundation.dart';
import 'package:uuid/uuid.dart';
import '../data/bible_repository.dart';
import '../data/achievements_catalog.dart';
import '../models/bible_models.dart';
import '../services/progress_repository.dart';
import '../services/points_service.dart';
import '../services/reading_plan_service.dart';
import '../services/notification_service.dart';

class AppState extends ChangeNotifier {
  final bible = BibleRepository.instance;
  final progress = ProgressRepository.instance;
  late final PointsService points;
  late final ReadingPlanService planService;
  final _uuid = const Uuid();

  bool _ready = false;
  bool get isReady => _ready;

  Future<void> init() async {
    await bible.load();
    await progress.init();
    points = PointsService(progress, bible);
    planService = ReadingPlanService(bible, progress);
    await NotificationService.instance.init();
    _ready = true;
    notifyListeners();
  }

  // ---------- Progress read-through ----------

  int get totalChapters => bible.totalChapters;
  int get completedChapters => progress.completedCount;
  double get percentComplete =>
      totalChapters == 0 ? 0 : (completedChapters / totalChapters) * 100;

  int get completedBooksCount => bible.books
      .where((b) => progress.completedChaptersForBook(b.id) == b.chapterCount)
      .length;

  int get currentStreak => progress.currentStreak;
  int get longestStreak => progress.longestStreak;
  int get totalPoints => progress.totalPoints;

  bool isChapterCompleted(String bookId, int chapterNumber) =>
      progress.isChapterCompleted('$bookId-$chapterNumber');

  int completedChaptersForBook(String bookId) => progress.completedChaptersForBook(bookId);

  /// Marks a chapter complete, awards points, updates streak/achievements,
  /// and notifies listeners. Returns the points earned, or null if the
  /// chapter was already completed (no duplicate points).
  Future<int?> completeChapter(String bookId, int chapterNumber) async {
    final wasNew = await progress.markChapterComplete(bookId, chapterNumber);
    if (!wasNew) return null;
    final earned = await points.awardForChapterCompletion(
      bookId: bookId,
      chapterNumber: chapterNumber,
    );
    notifyListeners();
    return earned;
  }

  Future<void> undoChapter(String bookId, int chapterNumber) async {
    await progress.undoChapterComplete(bookId, chapterNumber);
    notifyListeners();
  }

  AchievementStats get achievementStats => AchievementStats(
        chaptersCompleted: completedChapters,
        booksCompleted: completedBooksCount,
        currentStreak: currentStreak,
        longestStreak: longestStreak,
        percentComplete: percentComplete,
      );

  List<Achievement> get unlockedAchievements =>
      achievementsCatalog.where((a) => a.isUnlocked(achievementStats)).toList();

  List<Achievement> get lockedAchievements =>
      achievementsCatalog.where((a) => !a.isUnlocked(achievementStats)).toList();

  // ---------- Saved verses ----------

  List<SavedVerse> get savedVerses => progress.savedVerses;

  Future<void> addVerse({required String reference, required String text, String? note}) async {
    final verse = SavedVerse(
      id: _uuid.v4(),
      reference: reference,
      text: text,
      note: note,
      createdAt: DateTime.now(),
    );
    await progress.saveVerse(verse);
    await points.awardForSavedVerse();
    notifyListeners();
  }

  Future<void> toggleFavoriteVerse(SavedVerse verse) async {
    await progress.updateVerse(verse.copyWith(isFavorite: !verse.isFavorite));
    notifyListeners();
  }

  Future<void> deleteVerse(String id) async {
    await progress.deleteVerse(id);
    notifyListeners();
  }

  // ---------- Reading plan ----------

  ReadingPlan? get activePlan => progress.activePlan;

  Future<void> createPlan(int days) async {
    final plan = planService.createPlan(days: days);
    await progress.savePlan(plan);
    notifyListeners();
  }

  Future<void> recalculatePlanAfterFallingBehind() async {
    final plan = activePlan;
    if (plan == null) return;
    final updated = planService.recalculate(plan);
    await progress.savePlan(updated);
    notifyListeners();
  }

  Future<void> pausePlan() async {
    final plan = activePlan;
    if (plan == null) return;
    plan.status = PlanStatus.paused;
    await progress.savePlan(plan);
    notifyListeners();
  }

  Future<void> resumePlan() async {
    final plan = activePlan;
    if (plan == null) return;
    plan.status = PlanStatus.active;
    await progress.savePlan(plan);
    notifyListeners();
  }

  DateTime estimatedFinishDate(int chaptersPerDay) =>
      planService.estimatedFinishDate(chaptersPerDay: chaptersPerDay);

  // ---------- Settings ----------

  AppSettings get settings => progress.settings;

  Future<void> saveSettings(AppSettings s) async {
    await progress.saveSettings(s);
    notifyListeners();
  }
}
