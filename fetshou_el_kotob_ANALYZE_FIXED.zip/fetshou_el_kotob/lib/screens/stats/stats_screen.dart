import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../../providers/app_state.dart';
import '../../theme/app_theme.dart';

class StatsScreen extends StatelessWidget {
  const StatsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final bible = app.bible;

    final otCompleted = bible.oldTestamentBooks.fold<int>(0, (s, b) => s + app.completedChaptersForBook(b.id));
    final ntCompleted = bible.newTestamentBooks.fold<int>(0, (s, b) => s + app.completedChaptersForBook(b.id));

    final now = DateTime.now();
    final weekAgo = now.subtract(const Duration(days: 7));
    final monthAgo = now.subtract(const Duration(days: 30));
    final all = app.progress.allCompleted;
    final thisWeek = all.where((c) => c.completedAt.isAfter(weekAgo)).length;
    final thisMonth = all.where((c) => c.completedAt.isAfter(monthAgo)).length;

    double avgPerDay = 0;
    if (all.isNotEmpty) {
      final earliest = all.map((c) => c.completedAt).reduce((a, b) => a.isBefore(b) ? a : b);
      final daysSpan = now.difference(earliest).inDays + 1;
      avgPerDay = all.length / daysSpan;
    }

    final plan = app.activePlan;
    final estimated = plan != null ? app.estimatedFinishDate(plan.chaptersPerDay) : null;

    return Scaffold(
      appBar: AppBar(title: const Text('الإحصائيات')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  Text('${app.completedChapters} / ${app.totalChapters} إصحاح',
                      style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                  Text('${app.completedBooksCount} / ${bible.books.length} سفر'),
                  const SizedBox(height: 6),
                  Text('${app.percentComplete.toStringAsFixed(1)}%',
                      style: const TextStyle(fontSize: 28, fontWeight: FontWeight.bold, color: AppColors.primary)),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(child: _statCard('العهد القديم', '$otCompleted / ${bible.oldTestamentBooks.fold<int>(0, (s, b) => s + b.chapterCount)}')),
              const SizedBox(width: 12),
              Expanded(child: _statCard('العهد الجديد', '$ntCompleted / ${bible.newTestamentBooks.fold<int>(0, (s, b) => s + b.chapterCount)}')),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(child: _statCard('هذا الأسبوع', '$thisWeek إصحاح')),
              const SizedBox(width: 12),
              Expanded(child: _statCard('هذا الشهر', '$thisMonth إصحاح')),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(child: _statCard('متوسط يومي', avgPerDay.toStringAsFixed(1))),
              const SizedBox(width: 12),
              Expanded(child: _statCard('أطول سلسلة أيام', '${app.longestStreak}')),
            ],
          ),
          if (estimated != null) ...[
            const SizedBox(height: 12),
            _statCard('تاريخ الإتمام المتوقع', DateFormat('yyyy/MM/dd').format(estimated)),
          ],
        ],
      ),
    );
  }

  Widget _statCard(String label, String value) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Text(value, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: AppColors.primary)),
            const SizedBox(height: 4),
            Text(label, style: const TextStyle(fontSize: 12)),
          ],
        ),
      ),
    );
  }
}
