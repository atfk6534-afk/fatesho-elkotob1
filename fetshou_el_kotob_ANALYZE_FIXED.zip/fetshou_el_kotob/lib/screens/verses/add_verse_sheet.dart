import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/app_state.dart';

class AddVerseSheet extends StatefulWidget {
  final String promptTitle;
  const AddVerseSheet({super.key, this.promptTitle = 'أضف آية'});

  @override
  State<AddVerseSheet> createState() => _AddVerseSheetState();
}

class _AddVerseSheetState extends State<AddVerseSheet> {
  final _refController = TextEditingController();
  final _textController = TextEditingController();
  final _noteController = TextEditingController();

  @override
  void dispose() {
    _refController.dispose();
    _textController.dispose();
    _noteController.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (_textController.text.trim().isEmpty || _refController.text.trim().isEmpty) return;
    await context.read<AppState>().addVerse(
          reference: _refController.text.trim(),
          text: _textController.text.trim(),
          note: _noteController.text.trim().isEmpty ? null : _noteController.text.trim(),
        );
    if (mounted) Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).viewInsets.bottom + 20,
        left: 20,
        right: 20,
        top: 20,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Center(
            child: Container(
              width: 40,
              height: 4,
              margin: const EdgeInsets.only(bottom: 16),
              decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(4)),
            ),
          ),
          Text(widget.promptTitle, style: Theme.of(context).textTheme.titleMedium, textAlign: TextAlign.center),
          const SizedBox(height: 16),
          TextField(
            controller: _refController,
            decoration: const InputDecoration(labelText: 'المرجع (مثال: يوحنا 3:16)', border: OutlineInputBorder()),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _textController,
            maxLines: 3,
            decoration: const InputDecoration(labelText: 'نص الآية', border: OutlineInputBorder()),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _noteController,
            decoration: const InputDecoration(labelText: 'ملاحظة شخصية (اختياري)', border: OutlineInputBorder()),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: TextButton(
                  onPressed: () => Navigator.of(context).pop(),
                  child: const Text('لاحقًا'),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: ElevatedButton(onPressed: _save, child: const Text('حفظ الآية')),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
