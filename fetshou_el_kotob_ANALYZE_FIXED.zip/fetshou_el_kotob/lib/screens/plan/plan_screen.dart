import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../../providers/app_state.dart';
import '../../models/bible_models.dart';
import '../../theme/app_theme.dart';

class PlanScreen extends StatelessWidget {
  final bool embedded;
  const PlanScreen({super.key, this.embedded = false});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final plan = app.activePlan;

    final body = plan == null ? _NoPlanView() : _ActivePlanView(plan: plan);

    if (embedded) return body;
    return Scaffold(appBar: AppBar(title: const Text('خطة القراءة')), body: body);
  }
}

class _NoPlanView extends StatelessWidget {
  static const Map<String, int> options = {
    '30 يوم': 30,
    '60 يوم': 60,
    '90 يوم': 90,
    '6 شهور': 182,
    'سنة': 365,
  };

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.calendar_today_outlined, size: 56, color: AppColors.primary),
            const SizedBox(height: 16),
            Text('عايز تخلص الكتاب المقدس في قد إيه؟',
                textAlign: TextAlign.center, style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 20),
            Wrap(
              spacing: 10,
              runSpacing: 10,
              alignment: WrapAlignment.center,
              children: options.entries
                  .map((e) => ActionChip(
                        label: Text(e.key),
                        onPressed: () => app.createPlan(e.value),
                      ))
                  .toList(),
            ),
          ],
        ),
      ),
    );
  }
}

class _ActivePlanView extends StatelessWidget {
  final ReadingPlan plan;
  const _ActivePlanView({required this.plan});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final remaining = app.planService.remainingChapters;
    final daysLeft = plan.targetDate.difference(DateTime.now()).inDays;
    final isBehind = daysLeft <= 0 && remaining > 0;
    final estimatedFinish = app.estimatedFinishDate(plan.chaptersPerDay);
    final df = DateFormat('yyyy/MM/dd');

    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        if (isBehind)
          Container(
            width: double.infinity,
            margin: const EdgeInsets.only(bottom: 16),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(color: AppColors.accent.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(14)),
            child: Column(
              children: [
                Text('ولا يهمك ❤️\nنكمل من النهارده.', textAlign: TextAlign.center, style: Theme.of(context).textTheme.titleSmall),
                const SizedBox(height: 10),
                ElevatedButton(
                  onPressed: () => app.recalculatePlanAfterFallingBehind(),
                  child: const Text('إعادة حساب الخطة'),
                ),
              ],
            ),
          ),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              children: [
                Text('خطتك الحالية', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w600)),
                const SizedBox(height: 16),
                _row('إصحاحات اليوم', '${plan.chaptersPerDay}'),
                _row('الإصحاحات المتبقية', '$remaining'),
                _row('تاريخ البدء', df.format(plan.startDate)),
                _row('التاريخ المستهدف', df.format(plan.targetDate)),
                _row('تاريخ الإتمام المتوقع', df.format(estimatedFinish)),
                _row('الحالة', plan.status == PlanStatus.active ? 'نشطة' : plan.status == PlanStatus.paused ? 'متوقفة مؤقتًا' : 'مكتملة'),
              ],
            ),
          ),
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(
              child: OutlinedButton(
                onPressed: plan.status == PlanStatus.active ? () => app.pausePlan() : () => app.resumePlan(),
                child: Text(plan.status == PlanStatus.active ? 'إيقاف مؤقت' : 'استئناف'),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: OutlinedButton(
                onPressed: () => _showRestartDialog(context),
                child: const Text('تغيير الخطة'),
              ),
            ),
          ],
        ),
      ],
    );
  }

  void _showRestartDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (_) => SimpleDialog(
        title: const Text('اختر مدة جديدة'),
        children: _NoPlanView.options.entries
            .map((e) => SimpleDialogOption(
                  onPressed: () {
                    context.read<AppState>().createPlan(e.value);
                    Navigator.of(context).pop();
                  },
                  child: Text(e.key),
                ))
            .toList(),
      ),
    );
  }

  Widget _row(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [Text(label), Text(value, style: const TextStyle(fontWeight: FontWeight.bold))],
      ),
    );
  }
}
