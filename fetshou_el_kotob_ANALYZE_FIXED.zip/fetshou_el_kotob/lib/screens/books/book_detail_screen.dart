import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/app_state.dart';
import '../../theme/app_theme.dart';
import '../verses/add_verse_sheet.dart';

class BookDetailScreen extends StatelessWidget {
  final String bookId;
  const BookDetailScreen({super.key, required this.bookId});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final book = app.bible.bookById(bookId);

    return Scaffold(
      appBar: AppBar(title: Text(book.arabicName)),
      body: Column(
        children: [
          if (book.isDeuterocanonical && book.notes != null)
            Container(
              width: double.infinity,
              margin: const EdgeInsets.fromLTRB(16, 12, 16, 0),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: AppColors.accent.withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                children: [
                  const Icon(Icons.info_outline, color: AppColors.accent, size: 18),
                  const SizedBox(width: 8),
                  Expanded(child: Text(book.notes!, style: Theme.of(context).textTheme.bodySmall)),
                ],
              ),
            ),
          Expanded(
            child: GridView.builder(
              padding: const EdgeInsets.all(16),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 5,
                mainAxisSpacing: 10,
                crossAxisSpacing: 10,
              ),
              itemCount: book.chapterCount,
              itemBuilder: (context, i) {
                final chapterNumber = i + 1;
                final done = app.isChapterCompleted(book.id, chapterNumber);
                return _ChapterTile(
                  chapterNumber: chapterNumber,
                  done: done,
                  onTap: () async {
                    if (done) {
                      await app.undoChapter(book.id, chapterNumber);
                    } else {
                      final earned = await app.completeChapter(book.id, chapterNumber);
                      if (earned != null && context.mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(content: Text('إصحاح $chapterNumber ✓ (+$earned نقطة)')),
                        );
                        _maybeOfferSaveVerse(context);
                      }
                    }
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  void _maybeOfferSaveVerse(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (_) => const AddVerseSheet(promptTitle: 'في آية لمستك النهارده؟'),
    );
  }
}

class _ChapterTile extends StatelessWidget {
  final int chapterNumber;
  final bool done;
  final VoidCallback onTap;
  const _ChapterTile({required this.chapterNumber, required this.done, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(12),
      onTap: onTap,
      onLongPress: done ? onTap : null,
      child: Container(
        decoration: BoxDecoration(
          color: done ? AppColors.primary : AppColors.primary.withValues(alpha: 0.06),
          borderRadius: BorderRadius.circular(12),
        ),
        alignment: Alignment.center,
        child: Text(
          '$chapterNumber',
          style: TextStyle(
            color: done ? Colors.white : AppColors.primary,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
    );
  }
}
