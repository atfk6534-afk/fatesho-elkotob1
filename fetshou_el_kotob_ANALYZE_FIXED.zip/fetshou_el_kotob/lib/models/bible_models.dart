enum Testament { ot, nt }

Testament testamentFromString(String s) => s == 'OT' ? Testament.ot : Testament.nt;

/// A single Bible book, loaded from the canonical dataset (assets/data/bible_canon.json).
/// This is the single source of truth for book structure — never hard-code counts elsewhere.
class BibleBook {
  final String id;
  final String arabicName;
  final String englishName;
  final Testament testament;
  final int canonicalOrder;
  final int chapterCount;
  final bool isDeuterocanonical;
  final String? notes;

  const BibleBook({
    required this.id,
    required this.arabicName,
    required this.englishName,
    required this.testament,
    required this.canonicalOrder,
    required this.chapterCount,
    required this.isDeuterocanonical,
    this.notes,
  });

  factory BibleBook.fromJson(Map<String, dynamic> json) => BibleBook(
        id: json['id'] as String,
        arabicName: json['arabicName'] as String,
        englishName: json['englishName'] as String,
        testament: testamentFromString(json['testament'] as String),
        canonicalOrder: json['canonicalOrder'] as int,
        chapterCount: json['chapterCount'] as int,
        isDeuterocanonical: json['isDeuterocanonical'] as bool,
        notes: json['notes'] as String?,
      );

  /// Unique chapter id, e.g. "gen-1"
  String chapterId(int chapterNumber) => '$id-$chapterNumber';
}

class BibleMeta {
  final int totalBooks;
  final int oldTestamentBooks;
  final int newTestamentBooks;
  final int totalChapters;
  final int oldTestamentChapters;
  final int newTestamentChapters;

  const BibleMeta({
    required this.totalBooks,
    required this.oldTestamentBooks,
    required this.newTestamentBooks,
    required this.totalChapters,
    required this.oldTestamentChapters,
    required this.newTestamentChapters,
  });

  factory BibleMeta.fromJson(Map<String, dynamic> json) => BibleMeta(
        totalBooks: json['totalBooks'] as int,
        oldTestamentBooks: json['oldTestamentBooks'] as int,
        newTestamentBooks: json['newTestamentBooks'] as int,
        totalChapters: json['totalChapters'] as int,
        oldTestamentChapters: json['oldTestamentChapters'] as int,
        newTestamentChapters: json['newTestamentChapters'] as int,
      );
}

/// A record that a chapter has been completed. Stored in Hive.
class CompletedChapter {
  final String chapterId; // "gen-1"
  final String bookId;
  final int chapterNumber;
  final DateTime completedAt;

  CompletedChapter({
    required this.chapterId,
    required this.bookId,
    required this.chapterNumber,
    required this.completedAt,
  });

  Map<String, dynamic> toMap() => {
        'chapterId': chapterId,
        'bookId': bookId,
        'chapterNumber': chapterNumber,
        'completedAt': completedAt.toIso8601String(),
      };

  factory CompletedChapter.fromMap(Map map) => CompletedChapter(
        chapterId: map['chapterId'] as String,
        bookId: map['bookId'] as String,
        chapterNumber: map['chapterNumber'] as int,
        completedAt: DateTime.parse(map['completedAt'] as String),
      );
}

class SavedVerse {
  final String id;
  final String reference; // e.g. "يوحنا 3:16"
  final String text;
  final String? note;
  final DateTime createdAt;
  final bool isFavorite;

  SavedVerse({
    required this.id,
    required this.reference,
    required this.text,
    this.note,
    required this.createdAt,
    this.isFavorite = false,
  });

  SavedVerse copyWith({String? text, String? note, bool? isFavorite}) => SavedVerse(
        id: id,
        reference: reference,
        text: text ?? this.text,
        note: note ?? this.note,
        createdAt: createdAt,
        isFavorite: isFavorite ?? this.isFavorite,
      );

  Map<String, dynamic> toMap() => {
        'id': id,
        'reference': reference,
        'text': text,
        'note': note,
        'createdAt': createdAt.toIso8601String(),
        'isFavorite': isFavorite,
      };

  factory SavedVerse.fromMap(Map map) => SavedVerse(
        id: map['id'] as String,
        reference: map['reference'] as String,
        text: map['text'] as String,
        note: map['note'] as String?,
        createdAt: DateTime.parse(map['createdAt'] as String),
        isFavorite: (map['isFavorite'] as bool?) ?? false,
      );
}

enum PlanStatus { active, paused, completed }

class ReadingPlan {
  final String id;
  final DateTime startDate;
  final DateTime targetDate;
  final int totalChapters; // remaining chapters at plan creation time
  final int chaptersPerDay;
  PlanStatus status;

  ReadingPlan({
    required this.id,
    required this.startDate,
    required this.targetDate,
    required this.totalChapters,
    required this.chaptersPerDay,
    this.status = PlanStatus.active,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'startDate': startDate.toIso8601String(),
        'targetDate': targetDate.toIso8601String(),
        'totalChapters': totalChapters,
        'chaptersPerDay': chaptersPerDay,
        'status': status.name,
      };

  factory ReadingPlan.fromMap(Map map) => ReadingPlan(
        id: map['id'] as String,
        startDate: DateTime.parse(map['startDate'] as String),
        targetDate: DateTime.parse(map['targetDate'] as String),
        totalChapters: map['totalChapters'] as int,
        chaptersPerDay: map['chaptersPerDay'] as int,
        status: PlanStatus.values.firstWhere((e) => e.name == map['status'], orElse: () => PlanStatus.active),
      );
}

class Achievement {
  final String id;
  final String title;
  final String description;
  final String icon; // material icon name key, resolved in UI
  final bool Function(AchievementStats stats) isUnlocked;

  const Achievement({
    required this.id,
    required this.title,
    required this.description,
    required this.icon,
    required this.isUnlocked,
  });
}

class AchievementStats {
  final int chaptersCompleted;
  final int booksCompleted;
  final int currentStreak;
  final int longestStreak;
  final double percentComplete;

  const AchievementStats({
    required this.chaptersCompleted,
    required this.booksCompleted,
    required this.currentStreak,
    required this.longestStreak,
    required this.percentComplete,
  });
}

class AppSettings {
  bool notificationsEnabled;
  bool verseNotificationsEnabled;
  int preferredHour; // 0-23, reading reminder time
  int preferredMinute;
  String themeMode; // 'light' | 'dark' | 'system'
  String userName;
  bool onboardingComplete;

  AppSettings({
    this.notificationsEnabled = false,
    this.verseNotificationsEnabled = true,
    this.preferredHour = 20,
    this.preferredMinute = 0,
    this.themeMode = 'system',
    this.userName = '',
    this.onboardingComplete = false,
  });

  Map<String, dynamic> toMap() => {
        'notificationsEnabled': notificationsEnabled,
        'verseNotificationsEnabled': verseNotificationsEnabled,
        'preferredHour': preferredHour,
        'preferredMinute': preferredMinute,
        'themeMode': themeMode,
        'userName': userName,
        'onboardingComplete': onboardingComplete,
      };

  factory AppSettings.fromMap(Map map) => AppSettings(
        notificationsEnabled: (map['notificationsEnabled'] as bool?) ?? false,
        verseNotificationsEnabled: (map['verseNotificationsEnabled'] as bool?) ?? true,
        preferredHour: (map['preferredHour'] as int?) ?? 20,
        preferredMinute: (map['preferredMinute'] as int?) ?? 0,
        themeMode: (map['themeMode'] as String?) ?? 'system',
        userName: (map['userName'] as String?) ?? '',
        onboardingComplete: (map['onboardingComplete'] as bool?) ?? false,
      );
}
