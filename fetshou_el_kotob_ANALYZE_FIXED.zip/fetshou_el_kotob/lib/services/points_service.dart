import '../services/progress_repository.dart';
import '../data/bible_repository.dart';

/// Point values are centralized here (never hard-coded in the UI) so they
/// can be tuned without touching screen code.
class PointsConfig {
  static const int chapterComplete = 10;
  static const int firstChapterOfNewBook = 15;
  static const int finishEntireBook = 50;
  static const int streak7Days = 50;
  static const int streak30Days = 200;
  static const int saveVerse = 3;
}

/// Computes and awards points for reading actions. Guards against double
/// awarding by relying on ProgressRepository.markChapterComplete's
/// already-completed check happening *before* this is called.
class PointsService {
  final ProgressRepository progress;
  final BibleRepository bible;

  PointsService(this.progress, this.bible);

  /// Call *after* ProgressRepository.markChapterComplete returns true.
  Future<int> awardForChapterCompletion({
    required String bookId,
    required int chapterNumber,
  }) async {
    int earned = PointsConfig.chapterComplete;

    if (chapterNumber == 1) {
      earned += PointsConfig.firstChapterOfNewBook;
    }

    final book = bible.bookById(bookId);
    final completedInBook = progress.completedChaptersForBook(bookId);
    if (completedInBook == book.chapterCount) {
      earned += PointsConfig.finishEntireBook;
    }

    final streak = progress.currentStreak;
    if (streak == 7) earned += PointsConfig.streak7Days;
    if (streak == 30) earned += PointsConfig.streak30Days;

    await progress.addPoints(earned);
    return earned;
  }

  Future<int> awardForSavedVerse() async {
    await progress.addPoints(PointsConfig.saveVerse);
    return PointsConfig.saveVerse;
  }
}
