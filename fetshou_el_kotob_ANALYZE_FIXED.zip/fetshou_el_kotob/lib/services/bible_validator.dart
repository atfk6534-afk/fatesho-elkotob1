import '../models/bible_models.dart';

/// Result of validating the canonical Bible dataset.
class BibleValidationResult {
  final bool isValid;
  final List<String> errors;
  final Map<String, int> computed;

  const BibleValidationResult({
    required this.isValid,
    required this.errors,
    required this.computed,
  });

  @override
  String toString() {
    final buf = StringBuffer();
    buf.writeln('=== BibleValidator ===');
    computed.forEach((k, v) => buf.writeln('$k: $v'));
    if (isValid) {
      buf.writeln('✅ الدقة الكنسية سليمة (canon totals verified)');
    } else {
      buf.writeln('❌ فشل التحقق:');
      for (final e in errors) {
        buf.writeln(' - $e');
      }
    }
    return buf.toString();
  }
}

/// Developer utility that validates the bundled Bible dataset against the
/// Coptic Orthodox canonical targets. Run via `flutter test` (see
/// test/bible_validator_test.dart) or call BibleValidator.validate() at
/// app startup in debug mode.
class BibleValidator {
  /// Expected totals for the actual chapter records bundled in this app:
  /// 46 OT books / 1075 chapters and 27 NT books / 260 chapters.
  /// Some Coptic reference pages report 270 NT chapters; the app keeps that
  /// source-reported figure in BibleMeta but does not invent ten chapters.
  static const int expectedTotalBooks = 73;
  static const int expectedOtBooks = 46;
  static const int expectedNtBooks = 27;
  static const int expectedOtChapters = 1075;
  static const int expectedNtChapters = 260;
  static const int expectedTotalChapters = expectedOtChapters + expectedNtChapters; // 1335

  static BibleValidationResult validate(List<BibleBook> books) {
    final errors = <String>[];

    final otBooks = books.where((b) => b.testament == Testament.ot).toList();
    final ntBooks = books.where((b) => b.testament == Testament.nt).toList();

    final totalBooks = books.length;
    final otBookCount = otBooks.length;
    final ntBookCount = ntBooks.length;
    final otChapters = otBooks.fold<int>(0, (s, b) => s + b.chapterCount);
    final ntChapters = ntBooks.fold<int>(0, (s, b) => s + b.chapterCount);
    final totalChapters = otChapters + ntChapters;

    // Duplicate book IDs
    final ids = books.map((b) => b.id).toList();
    final dupIds = ids.toSet().where((id) => ids.where((i) => i == id).length > 1);
    if (dupIds.isNotEmpty) {
      errors.add('معرفات أسفار مكررة (duplicate book ids): ${dupIds.join(', ')}');
    }

    // Duplicate canonical order
    final orders = books.map((b) => b.canonicalOrder).toList();
    final dupOrders = orders.toSet().where((o) => orders.where((x) => x == o).length > 1);
    if (dupOrders.isNotEmpty) {
      errors.add('ترتيب قانوني مكرر (duplicate canonicalOrder): ${dupOrders.join(', ')}');
    }

    // Every book must have >0 chapters
    for (final b in books) {
      if (b.chapterCount <= 0) {
        errors.add('سفر بعدد إصحاحات غير صالح: ${b.id}');
      }
    }

    // Duplicate chapter IDs across the whole canon
    final chapterIds = <String>[];
    for (final b in books) {
      for (var c = 1; c <= b.chapterCount; c++) {
        chapterIds.add(b.chapterId(c));
      }
    }
    final dupChapterIds = chapterIds.toSet().where((id) => chapterIds.where((c) => c == id).length > 1);
    if (dupChapterIds.isNotEmpty) {
      errors.add('معرفات إصحاحات مكررة: ${dupChapterIds.join(', ')}');
    }

    if (totalBooks != expectedTotalBooks) {
      errors.add('إجمالي الأسفار $totalBooks لا يساوي المتوقع $expectedTotalBooks');
    }
    if (otBookCount != expectedOtBooks) {
      errors.add('أسفار العهد القديم $otBookCount لا تساوي المتوقع $expectedOtBooks');
    }
    if (ntBookCount != expectedNtBooks) {
      errors.add('أسفار العهد الجديد $ntBookCount لا تساوي المتوقع $expectedNtBooks');
    }
    if (otChapters != expectedOtChapters) {
      errors.add('إصحاحات العهد القديم $otChapters لا تساوي المتوقع $expectedOtChapters');
    }
    if (ntChapters != expectedNtChapters) {
      errors.add('إصحاحات العهد الجديد $ntChapters لا تساوي المتوقع $expectedNtChapters');
    }
    if (otBookCount + ntBookCount != totalBooks) {
      errors.add('OT + NT books != total books');
    }
    if (otChapters + ntChapters != totalChapters) {
      errors.add('OT + NT chapters != total chapters');
    }

    return BibleValidationResult(
      isValid: errors.isEmpty,
      errors: errors,
      computed: {
        'totalBooks': totalBooks,
        'oldTestamentBooks': otBookCount,
        'newTestamentBooks': ntBookCount,
        'totalChapters': totalChapters,
        'oldTestamentChapters': otChapters,
        'newTestamentChapters': ntChapters,
      },
    );
  }
}
