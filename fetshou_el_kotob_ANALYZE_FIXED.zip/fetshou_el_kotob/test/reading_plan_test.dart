import 'package:flutter_test/flutter_test.dart';

void main() {
  group('reading plan math', () {
    test('chapters-per-day divides remaining chapters, not book count', () {
      const totalChapters = 1335;
      const completed = 0;
      const days = 90;
      final remaining = totalChapters - completed;
      final perDay = (remaining / days).ceil();
      expect(perDay, 15); // 1335/90 = 14.8... -> 15
    });

    test('progress percentage uses full precision, not pre-rounded', () {
      const completed = 1;
      const total = 1335;
      final percent = completed / total * 100;
      expect(percent, closeTo(0.0749, 0.001));
    });

    test('100% only when every chapter is completed', () {
      const completed = 1335;
      const total = 1335;
      final percent = completed / total * 100;
      expect(percent, 100);
    });
  });
}
