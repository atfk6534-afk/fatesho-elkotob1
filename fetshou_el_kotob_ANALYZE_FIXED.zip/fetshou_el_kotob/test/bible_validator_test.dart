import 'dart:convert';
import 'dart:io';
import 'package:flutter_test/flutter_test.dart';
import 'package:fetshou_el_kotob/models/bible_models.dart';
import 'package:fetshou_el_kotob/services/bible_validator.dart';

List<BibleBook> _loadBooksFromDisk() {
  final raw = File('assets/data/bible_canon.json').readAsStringSync();
  final json = jsonDecode(raw) as Map<String, dynamic>;
  return (json['books'] as List).map((b) => BibleBook.fromJson(b as Map<String, dynamic>)).toList();
}

void main() {
  group('BibleValidator', () {
    late List<BibleBook> books;

    setUpAll(() {
      books = _loadBooksFromDisk();
    });

    test('total book and chapter counts match Coptic Orthodox targets', () {
      final result = BibleValidator.validate(books);
      expect(result.computed['totalBooks'], 73);
      expect(result.computed['oldTestamentBooks'], 46);
      expect(result.computed['newTestamentBooks'], 27);
      expect(result.computed['oldTestamentChapters'], 1075);
      expect(result.computed['newTestamentChapters'], 260);
      expect(result.isValid, isTrue, reason: result.errors.join('; '));
    });

    test('no duplicate book ids', () {
      final ids = books.map((b) => b.id).toSet();
      expect(ids.length, books.length);
    });

    test('no duplicate canonical order values', () {
      final orders = books.map((b) => b.canonicalOrder).toSet();
      expect(orders.length, books.length);
    });

    test('every book has a positive chapter count', () {
      for (final b in books) {
        expect(b.chapterCount, greaterThan(0), reason: b.id);
      }
    });

    test('OT + NT books equal total books', () {
      final ot = books.where((b) => b.testament == Testament.ot).length;
      final nt = books.where((b) => b.testament == Testament.nt).length;
      expect(ot + nt, books.length);
    });

    test('Deuterocanonical books are integrated into OT, not a separate section', () {
      final deutero = books.where((b) => b.isDeuterocanonical);
      expect(deutero.every((b) => b.testament == Testament.ot), isTrue);
      // Confirms Tobit/Judith/Wisdom/Sirach/Baruch/1-2 Maccabees are present.
      final ids = books.map((b) => b.id).toSet();
      for (final id in ['tob', 'jdt', 'wis', 'sir', 'bar', '1ma', '2ma']) {
        expect(ids.contains(id), isTrue, reason: 'missing $id');
      }
      // Esther and Daniel remain single books (additions folded in), not split out.
      expect(ids.where((i) => i == 'est').length, 1);
      expect(ids.where((i) => i == 'dan').length, 1);
    });
  });
}
