import 'dart:math';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/timezone.dart' as tz;
import 'package:timezone/data/latest_all.dart' as tzdata;
import 'package:permission_handler/permission_handler.dart';
import '../models/bible_models.dart';

/// Wraps flutter_local_notifications for the two notification kinds the
/// app needs: a daily reading reminder, and a daily "verse of the day"
/// pulled from the user's saved verses. Both are scheduled inside a
/// randomized window around the user's preferred time so they don't feel
/// robotic, and both work entirely offline (local notifications only).
class NotificationService {
  NotificationService._();
  static final NotificationService instance = NotificationService._();

  final _plugin = FlutterLocalNotificationsPlugin();
  bool _initialized = false;

  static const _readingReminderId = 1001;
  static const _verseNotificationId = 1002;
  static const _channelId = 'daily_reading';
  static const _channelName = 'تذكير القراءة اليومي';

  Future<void> init() async {
    if (_initialized) return;
    tzdata.initializeTimeZones();
    const androidInit = AndroidInitializationSettings('@mipmap/ic_launcher');
    const initSettings = InitializationSettings(android: androidInit);
    await _plugin.initialize(initSettings);

    const channel = AndroidNotificationChannel(
      _channelId,
      _channelName,
      description: 'تذكيرات القراءة اليومية وآية اليوم',
      importance: Importance.high,
    );
    await _plugin
        .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()
        ?.createNotificationChannel(channel);

    _initialized = true;
  }

  /// Requests POST_NOTIFICATIONS on Android 13+. Caller is responsible for
  /// showing an explanatory screen *before* calling this (see onboarding).
  Future<bool> requestPermission() async {
    final status = await Permission.notification.request();
    return status.isGranted;
  }

  Future<bool> hasPermission() async => Permission.notification.isGranted;

  /// Schedules the daily reading reminder at a randomized time within
  /// +/- [windowMinutes] of the preferred hour/minute, so it doesn't fire
  /// at the exact same second every day.
  Future<void> scheduleDailyReminder({
    required int preferredHour,
    required int preferredMinute,
    int windowMinutes = 30,
  }) async {
    await _plugin.cancel(_readingReminderId);
    final time = _randomizedTime(preferredHour, preferredMinute, windowMinutes);
    await _plugin.zonedSchedule(
      _readingReminderId,
      'وقت كلمة ربنا ❤️',
      'إصحاحك النهارده مستنيك.',
      time,
      const NotificationDetails(
        android: AndroidNotificationDetails(_channelId, _channelName, importance: Importance.high),
      ),
      androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
      matchDateTimeComponents: DateTimeComponents.time,
    );
  }

  Future<void> cancelDailyReminder() => _plugin.cancel(_readingReminderId);

  /// Schedules today's verse notification from a random saved verse. Call
  /// this once a day (e.g. from a periodic recheck or on app open) with
  /// the current verse list, since flutter_local_notifications doesn't
  /// pick random content itself.
  Future<void> scheduleVerseNotification({
    required List<SavedVerse> verses,
    required int preferredHour,
    required int preferredMinute,
    int windowMinutes = 30,
  }) async {
    await _plugin.cancel(_verseNotificationId);
    if (verses.isEmpty) return;
    final verse = verses[Random().nextInt(verses.length)];
    final time = _randomizedTime(preferredHour, preferredMinute, windowMinutes);
    final shortText = verse.text.length > 90 ? '${verse.text.substring(0, 90)}…' : verse.text;
    await _plugin.zonedSchedule(
      _verseNotificationId,
      'آية النهارده 📖',
      '$shortText — ${verse.reference}',
      time,
      const NotificationDetails(
        android: AndroidNotificationDetails(_channelId, _channelName, importance: Importance.defaultImportance),
      ),
      androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
      matchDateTimeComponents: DateTimeComponents.time,
    );
  }

  Future<void> cancelVerseNotification() => _plugin.cancel(_verseNotificationId);

  Future<void> cancelAll() => _plugin.cancelAll();

  tz.TZDateTime _randomizedTime(int hour, int minute, int windowMinutes) {
    final now = tz.TZDateTime.now(tz.local);
    final offset = Random().nextInt(windowMinutes * 2 + 1) - windowMinutes; // -window..+window
    var scheduled = tz.TZDateTime(tz.local, now.year, now.month, now.day, hour, minute)
        .add(Duration(minutes: offset));
    if (scheduled.isBefore(now)) {
      scheduled = scheduled.add(const Duration(days: 1));
    }
    return scheduled;
  }
}
