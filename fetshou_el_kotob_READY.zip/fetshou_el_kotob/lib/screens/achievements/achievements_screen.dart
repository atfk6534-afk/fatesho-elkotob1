import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/app_state.dart';
import '../../models/bible_models.dart';
import '../../theme/app_theme.dart';

const Map<String, IconData> _iconMap = {
  'auto_stories': Icons.auto_stories,
  'menu_book': Icons.menu_book,
  'local_fire_department': Icons.local_fire_department,
  'whatshot': Icons.whatshot,
  'stacked_bar_chart': Icons.stacked_bar_chart,
  'leaderboard': Icons.leaderboard,
  'flag': Icons.flag,
  'emoji_events': Icons.emoji_events,
};

class AchievementsScreen extends StatelessWidget {
  const AchievementsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final unlocked = app.unlockedAchievements;
    final locked = app.lockedAchievements;

    return Scaffold(
      appBar: AppBar(title: const Text('الإنجازات')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              mainAxisSpacing: 12,
              crossAxisSpacing: 12,
              childAspectRatio: 1.05,
            ),
            itemCount: unlocked.length + locked.length,
            itemBuilder: (context, i) {
              final isUnlocked = i < unlocked.length;
              final a = isUnlocked ? unlocked[i] : locked[i - unlocked.length];
              return _AchievementTile(achievement: a, unlocked: isUnlocked);
            },
          ),
        ],
      ),
    );
  }
}

class _AchievementTile extends StatelessWidget {
  final Achievement achievement;
  final bool unlocked;
  const _AchievementTile({required this.achievement, required this.unlocked});

  @override
  Widget build(BuildContext context) {
    return Card(
      color: unlocked ? null : Colors.grey.withOpacity(0.08),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              _iconMap[achievement.icon] ?? Icons.star,
              size: 36,
              color: unlocked ? AppColors.accent : Colors.grey,
            ),
            const SizedBox(height: 8),
            Text(
              achievement.title,
              textAlign: TextAlign.center,
              style: TextStyle(fontWeight: FontWeight.w600, color: unlocked ? null : Colors.grey),
            ),
            const SizedBox(height: 4),
            Text(
              achievement.description,
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 11, color: unlocked ? Colors.grey[600] : Colors.grey[400]),
            ),
          ],
        ),
      ),
    );
  }
}
